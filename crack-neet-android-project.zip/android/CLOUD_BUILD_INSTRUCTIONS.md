# CRACK NEET — External Cloud Build Instructions

This project is a 100% standard Android Gradle project (generated with Capacitor).

## Project Specifications:
- **Application ID / Package Name**: `in.crackneet.app`
- **Application Name**: `CRACK NEET`
- **Minimum Android SDK**: `24` (Android 7.0 Nougat)
- **Target Android SDK**: `34` (Android 14)
- **Compile SDK**: `36` (Android 16 / VanillaIceCream — required by androidx.core 1.17.0)
- **Java Requirement**: OpenJDK 17

---

## Option 1: Build in Cloud via GitHub Actions (Free & Zero Setup)
If you do not have Android Studio on your local machine, you can build the APK for free in GitHub:
1. Create a new GitHub repository (public or private).
2. Unzip this package and push it to your repository.
3. Add the following workflow file at `.github/workflows/build-apk.yml`:
```yaml
name: Build Android APK
on: [push, workflow_dispatch]

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'
      - name: Make Gradle executable
        run: chmod +x ./gradlew
      - name: Build Debug APK
        run: ./gradlew assembleDebug --no-daemon
      - name: Upload APK Artifact
        uses: actions/upload-artifact@v4
        with:
          name: crack-neet-app-debug
          path: app/build/outputs/apk/debug/app-debug.apk
```
4. Push to GitHub. The GitHub Action will run and automatically provide your compiled `app-debug.apk` in the **Actions** tab for download.

---

## Option 2: Build Locally in Android Studio
1. Open **Android Studio**.
2. Select **File -> Open...** and select this extracted `android` directory.
3. Wait for Gradle sync to complete.
4. Select **Build -> Build Bundle(s) / APK(s) -> Build APK(s)**.
5. The generated APK will be at:
   `app/build/outputs/apk/debug/app-debug.apk`

---

## Option 3: Build via Command Line
With JDK 17 and Android SDK installed on your system:
```bash
chmod +x ./gradlew
./gradlew assembleDebug
```
Output:
`app/build/outputs/apk/debug/app-debug.apk`
