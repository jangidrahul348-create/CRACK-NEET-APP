package in.crackneet.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
